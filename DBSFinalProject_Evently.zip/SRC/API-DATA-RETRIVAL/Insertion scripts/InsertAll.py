print("Inserting Countries...")
import InsertCountries

print("Inserting Cities...")
import insertCities

print("Inserting Artists...")
import InsertArtists

print("Inserting Albums...")
import InsertAlbums

print("Inserting Tracks...")
import InsertTracks

print("Inserting Events...")
import InsertEvents

print("DONE")

