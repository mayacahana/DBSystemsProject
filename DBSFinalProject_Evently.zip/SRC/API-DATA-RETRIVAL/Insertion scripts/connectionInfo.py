import os

SERVER_NAME = "127.0.0.1"
SERVER_PORT = 3305
DB_USERNAME = "DbMysql11"
DB_PASSWORD = "DbMysql11"
DB_NAME = "DbMysql11"
PATH_ROOT = os.path.dirname(os.getcwd())
